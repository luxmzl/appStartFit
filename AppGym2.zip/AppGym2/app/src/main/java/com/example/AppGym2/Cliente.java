/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.AppGym2;

/**
 *
 * @author fl1pc02
 */
public class Cliente {
    private int idCliente;
    private String nombreCompleto;
    private String cedula;
    private String telefono;
    private String correo;

    public Cliente(int idCliente, String nombreCompleto, String cedula, String telefono, String correo) {
        this.idCliente = idCliente;
        this.nombreCompleto = nombreCompleto;
        this.cedula = cedula;
        this.telefono = telefono;
        this.correo = correo;
    }

    public int getIdCliente() { return idCliente; }
    public String getNombreCompleto() { return nombreCompleto; }
    public String getCedula() { return cedula; }
    public String getTelefono() { return telefono; }
    public String getCorreo() { return correo; }
}
